package com.example.myapplication1;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraManager;
import android.os.Handler;
import android.view.SurfaceHolder;
import android.view.SurfaceView;

import java.util.ArrayList;
import java.util.List;

public class GameView extends SurfaceView implements SurfaceHolder.Callback {

    private GameThread gameThread;
    private Paint paint;
    private Ball ball;
    private List<Obstacle> obstacles;
    private boolean isGameOver = false;
    private boolean hasWon = false;
    private CameraManager cameraManager;
    private String cameraId;
    private Handler handler;

    public GameView(Context context) {
        super(context);
        getHolder().addCallback(this);
        paint = new Paint();
        ball = new Ball(100, 100, 30);
        obstacles = new ArrayList<>();
        handler = new Handler();

        // Akadályok hozzáadása
        obstacles.add(new Obstacle(300, 500, 500, 600));
        obstacles.add(new Obstacle(600, 1000, 800, 1100));

        // Kamera beállítása a vakuhoz
        cameraManager = (CameraManager) context.getSystemService(Context.CAMERA_SERVICE);
        try {
            cameraId = cameraManager.getCameraIdList()[0];
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceCreated(SurfaceHolder holder) {
        gameThread = new GameThread(this, holder);
        gameThread.setRunning(true);
        gameThread.start();
    }

    @Override
    public void surfaceChanged(SurfaceHolder holder, int format, int width, int height) {}

    @Override
    public void surfaceDestroyed(SurfaceHolder holder) {
        gameThread.setRunning(false);
    }

    public void updateBallPosition(float dx, float dy) {
        if (!isGameOver && !hasWon) {
            ball.update(dx, dy);
            checkCollisions();
        }
    }

    private void checkCollisions() {
        for (Obstacle obstacle : obstacles) {
            if (obstacle.collidesWith(ball)) {
                isGameOver = true;
            }
        }

        // Ha a célba érünk
        if (ball.x > 900 && ball.x < 1000 && ball.y > 1600 && ball.y < 1700) {
            hasWon = true;
            startFlashBlink();
        }
    }

    private void startFlashBlink() {
        new Thread(() -> {
            try {
                for (int i = 0; i < 6; i++) {
                    toggleFlash(true);
                    Thread.sleep(300);
                    toggleFlash(false);
                    Thread.sleep(300);
                }
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();
    }

    private void toggleFlash(boolean state) {
        try {
            cameraManager.setTorchMode(cameraId, state);
        } catch (CameraAccessException e) {
            e.printStackTrace();
        }
    }

    public void resetGame() {
        ball.x = 100;
        ball.y = 100;
        isGameOver = false;
        hasWon = false;
    }

    @Override
    public void draw(Canvas canvas) {
        super.draw(canvas);
        if (canvas != null) {
            canvas.drawColor(Color.WHITE);

            paint.setColor(Color.RED);
            canvas.drawRect(900, 1600, 1000, 1700, paint);

            paint.setColor(Color.BLACK);
            for (Obstacle obstacle : obstacles) {
                canvas.drawRect(obstacle.left, obstacle.top, obstacle.right, obstacle.bottom, paint);
            }

            paint.setColor(Color.BLUE);
            canvas.drawCircle(ball.x, ball.y, ball.radius, paint);

            // Game Over szöveg
            if (isGameOver) {
                paint.setColor(Color.BLACK);
                paint.setTextSize(100);
                canvas.drawText("Game Over", 400, 900, paint);
            }

            // You Win szöveg
            if (hasWon) {
                paint.setColor(Color.GREEN);
                paint.setTextSize(100);
                canvas.drawText("You Win!", 400, 900, paint);
            }
        }
    }
}
