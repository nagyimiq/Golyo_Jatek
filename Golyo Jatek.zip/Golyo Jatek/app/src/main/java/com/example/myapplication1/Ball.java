package com.example.myapplication1;
import android.content.res.Resources;

public class Ball {
    public float x, y;
    public float radius;

    private final int screenWidth = Resources.getSystem().getDisplayMetrics().widthPixels;
    private final int screenHeight = Resources.getSystem().getDisplayMetrics().heightPixels;

    public Ball(float x, float y, float radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
    }

    public void update(float dx, float dy) {
        float newX = x + dx * 5;
        float newY = y + dy * 5;

        // Ne menjen ki a képernyőn kívülre
        if (newX - radius >= 0 && newX + radius <= screenWidth) {
            x = newX;
        }
        if (newY - radius >= 0 && newY + radius <= screenHeight) {
            y = newY;
        }
    }
}

