package com.example.myapplication1;

public class Obstacle {
    public float left, top, right, bottom;

    public Obstacle(float left, float top, float right, float bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
    }

    public boolean collidesWith(Ball ball) {
        return ball.x + ball.radius > left && ball.x - ball.radius < right &&
                ball.y + ball.radius > top && ball.y - ball.radius < bottom;
    }
}
